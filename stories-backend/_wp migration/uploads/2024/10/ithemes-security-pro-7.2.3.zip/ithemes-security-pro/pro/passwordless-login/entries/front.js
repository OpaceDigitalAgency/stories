/**
 * WordPress dependencies
 */
import { render } from '@wordpress/element';
import domReady from '@wordpress/dom-ready';

/**
 * Internal dependencies
 */
import { App } from '@ithemes/security.passwordless-login.profile';

domReady( () => {
	const el = document.getElementById( 'itsec-passwordless-login-frontend-root' );

	if ( el ) {
		const userId = Number.parseInt( el.dataset.user, 10 );
		render( <App userId={ userId } useShadow />, el );
	}
} );
